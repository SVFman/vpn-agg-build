package com.personal.vpnagg

import android.util.Base64
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import java.io.IOException
import java.util.concurrent.TimeUnit

/**
 * Собирает все источники в ОДИН общий список (как требовалось), и только
 * после этого убирает дубликаты (точное совпадение строки), оставляя
 * первое вхождение каждой уникальной записи.
 */
object Aggregator {

    data class AggregationResult(
        val totalCollected: Int,
        val lines: List<String>,
        val errors: Map<String, String>
    )

    private val client: OkHttpClient by lazy {
        OkHttpClient.Builder()
            .connectTimeout(10, TimeUnit.SECONDS)
            .readTimeout(15, TimeUnit.SECONDS)
            .build()
    }

    suspend fun aggregate(urls: List<String>): AggregationResult = withContext(Dispatchers.IO) {
        val errors = mutableMapOf<String, String>()
        val allLines = mutableListOf<String>()

        // 1) Параллельно тянем все источники
        val deferred = urls.map { url ->
            async {
                url to try {
                    val body = fetchText(url)
                    extractConfigs(body)
                } catch (e: Exception) {
                    errors[url] = e.message ?: e.javaClass.simpleName
                    emptyList()
                }
            }
        }

        // 2) Сначала собираем всё в единый общий список (в исходном порядке источников)
        deferred.awaitAll().forEach { (_, lines) ->
            allLines.addAll(lines)
        }

        val totalCollected = allLines.size

        // 3) И только потом убираем дубликаты из общего списка
        val deduped = LinkedHashSet(allLines).toList()

        AggregationResult(
            totalCollected = totalCollected,
            lines = deduped,
            errors = errors
        )
    }

    private fun fetchText(url: String): String {
        val request = Request.Builder()
            .url(url)
            .header("User-Agent", "Mozilla/5.0 (Android) VpnAggregator/1.0")
            .build()

        client.newCall(request).execute().use { response ->
            if (!response.isSuccessful) {
                throw IOException("HTTP ${response.code}")
            }
            return response.body?.string() ?: throw IOException("Пустой ответ")
        }
    }

    /**
     * Ищет строки vless:// и vmess:// как есть, а если напрямую ничего не нашлось —
     * пробует раскодировать весь контент как base64 (классический формат подписки
     * вида All_Configs_base64_Sub.txt) и ищет конфиги уже там.
     */
    private fun extractConfigs(raw: String): List<String> {
        val direct = scanLines(raw)
        if (direct.isNotEmpty()) return direct

        val decoded = tryBase64Decode(raw.trim()) ?: return emptyList()
        return scanLines(decoded)
    }

    private fun scanLines(text: String): List<String> {
        val result = mutableListOf<String>()
        text.lineSequence().forEach { rawLine ->
            val line = rawLine.trim()
            if (line.startsWith("vless://") || line.startsWith("vmess://")) {
                result.add(line)
            }
        }
        return result
    }

    private fun tryBase64Decode(content: String): String? {
        return try {
            val cleaned = content.replace("\n", "").replace("\r", "").replace(" ", "")
            if (cleaned.isEmpty()) return null
            val bytes = Base64.decode(cleaned, Base64.DEFAULT)
            String(bytes, Charsets.UTF_8)
        } catch (e: Exception) {
            null
        }
    }
}
