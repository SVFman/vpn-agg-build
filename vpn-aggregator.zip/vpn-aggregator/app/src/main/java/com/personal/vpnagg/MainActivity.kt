package com.personal.vpnagg

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.util.Base64
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.FileProvider
import androidx.lifecycle.lifecycleScope
import com.personal.vpnagg.databinding.ActivityMainBinding
import kotlinx.coroutines.launch
import java.io.File

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding

    private var lastAggregatedLines: List<String> = emptyList()
    private var lastBase64Subscription: String = ""

    // Сколько строк показываем на экране. Полный список всё равно
    // сохраняется целиком в файл/буфер — ограничение только для UI,
    // чтобы не класть в TextView тысячи строк и не ловить OOM.
    private val previewLimit = 300

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.btnCopyBase64.isEnabled = false
        binding.btnSave.isEnabled = false

        binding.btnUpdate.setOnClickListener { runAggregation() }
        binding.btnCopyBase64.setOnClickListener { copyBase64ToClipboard() }
        binding.btnSave.setOnClickListener { saveAndShareFiles() }
    }

    private fun runAggregation() {
        binding.btnUpdate.isEnabled = false
        binding.btnCopyBase64.isEnabled = false
        binding.btnSave.isEnabled = false
        binding.tvStatus.text = "Опрашиваю ${Sources.URLS.size} источников…"
        binding.tvResult.text = ""

        lifecycleScope.launch {
            val result = Aggregator.aggregate(Sources.URLS)

            lastAggregatedLines = result.lines
            lastBase64Subscription = Base64.encodeToString(
                result.lines.joinToString("\n").toByteArray(Charsets.UTF_8),
                Base64.NO_WRAP
            )

            binding.tvStatus.text = buildStatusText(result)
            binding.tvResult.text = buildPreviewText(result.lines)

            val hasData = result.lines.isNotEmpty()
            binding.btnCopyBase64.isEnabled = hasData
            binding.btnSave.isEnabled = hasData
            binding.btnUpdate.isEnabled = true
        }
    }

    private fun buildPreviewText(lines: List<String>): String {
        if (lines.isEmpty()) {
            return "Ни одной строки vless:// или vmess:// не найдено."
        }
        val preview = lines.take(previewLimit).joinToString("\n")
        return if (lines.size > previewLimit) {
            "$preview\n\n… показаны первые $previewLimit из ${lines.size} строк.\n" +
                "Полный список — в base64 (кнопка «Скопировать») или в сохранённых файлах."
        } else {
            preview
        }
    }

    private fun buildStatusText(result: Aggregator.AggregationResult): String {
        val sb = StringBuilder()
        sb.append("Источников опрошено: ${Sources.URLS.size}\n")
        sb.append("Из них с ошибкой: ${result.errors.size}\n")
        sb.append("Собрано строк всего (с дублями): ${result.totalCollected}\n")
        sb.append("После удаления дублей: ${result.lines.size}\n")

        if (result.errors.isNotEmpty()) {
            sb.append("\nОшибки загрузки:\n")
            result.errors.forEach { (url, message) ->
                sb.append("• $url — $message\n")
            }
        }
        return sb.toString()
    }

    private fun copyBase64ToClipboard() {
        if (lastBase64Subscription.isEmpty()) return
        val clipboard = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        clipboard.setPrimaryClip(ClipData.newPlainText("vpn-subscription-base64", lastBase64Subscription))
        Toast.makeText(this, "Base64-подписка скопирована в буфер обмена", Toast.LENGTH_SHORT).show()
    }

    private fun saveAndShareFiles() {
        if (lastAggregatedLines.isEmpty()) return

        try {
            val outDir = File(getExternalFilesDir(null), "output").apply { mkdirs() }
            val plainFile = File(outDir, "aggregated.txt")
            val base64File = File(outDir, "aggregated_base64.txt")

            plainFile.writeText(lastAggregatedLines.joinToString("\n"), Charsets.UTF_8)
            base64File.writeText(lastBase64Subscription, Charsets.UTF_8)

            val authority = "$packageName.fileprovider"
            val uris = arrayListOf(
                FileProvider.getUriForFile(this, authority, plainFile),
                FileProvider.getUriForFile(this, authority, base64File)
            )

            val shareIntent = Intent(Intent.ACTION_SEND_MULTIPLE).apply {
                type = "text/plain"
                putParcelableArrayListExtra(Intent.EXTRA_STREAM, uris)
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }
            startActivity(Intent.createChooser(shareIntent, "Поделиться файлами подписки"))

            Toast.makeText(
                this,
                "Сохранено в: ${outDir.absolutePath}",
                Toast.LENGTH_LONG
            ).show()
        } catch (e: Exception) {
            Toast.makeText(this, "Ошибка сохранения: ${e.message}", Toast.LENGTH_LONG).show()
        }
    }
}