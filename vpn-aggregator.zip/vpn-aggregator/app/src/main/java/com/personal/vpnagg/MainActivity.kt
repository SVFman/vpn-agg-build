package com.personal.vpnagg

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.util.Base64
import android.util.Base64OutputStream
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.FileProvider
import androidx.lifecycle.lifecycleScope
import com.personal.vpnagg.databinding.ActivityMainBinding
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.BufferedWriter
import java.io.File
import java.io.FileOutputStream
import java.io.OutputStreamWriter

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding

    private var lastPlainFile: File? = null
    private var lastBase64File: File? = null

    private val previewLimit = 300

    // Потолок на итоговый список: защита от переполнения памяти, если
    // источники суммарно отдают огромное число записей, и от практически
    // бесполезной подписки на сотни тысяч серверов для v2rayNG.
    private val maxOutputLines = 50_000

    // Выше этого размера файл не читаем целиком в память для буфера обмена —
    // используем "Сохранить/поделиться" вместо этого.
    private val clipboardSafeSizeBytes = 2L * 1024 * 1024

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.btnCopyBase64.isEnabled = false
        binding.btnSave.isEnabled = false

        binding.btnUpdate.setOnClickListener { runAggregation() }
        binding.btnCopyBase64.setOnClickListener { copyBase64ToClipboard() }
        binding.btnSave.setOnClickListener { shareFiles() }
    }

    private fun runAggregation() {
        binding.btnUpdate.isEnabled = false
        binding.btnCopyBase64.isEnabled = false
        binding.btnSave.isEnabled = false
        binding.tvStatus.text = "Опрашиваю ${Sources.URLS.size} источников…"
        binding.tvResult.text = ""

        lifecycleScope.launch {
            val result = Aggregator.aggregate(Sources.URLS)

            val truncated = result.lines.size > maxOutputLines
            val outputLines = if (truncated) result.lines.take(maxOutputLines) else result.lines

            val files = withContext(Dispatchers.IO) {
                writeOutputFiles(outputLines)
            }
            lastPlainFile = files.first
            lastBase64File = files.second

            binding.tvStatus.text = buildStatusText(result, outputLines.size, truncated)
            binding.tvResult.text = buildPreviewText(outputLines)

            val hasData = outputLines.isNotEmpty()
            binding.btnCopyBase64.isEnabled = hasData
            binding.btnSave.isEnabled = hasData
            binding.btnUpdate.isEnabled = true
        }
    }

    /**
     * Пишет оба файла построчно (стримингом), ни разу не собирая весь
     * список в одну гигантскую строку/массив байт в памяти — именно
     * это раньше приводило к OutOfMemoryError на больших списках.
     */
    private fun writeOutputFiles(lines: List<String>): Pair<File, File> {
        val outDir = File(getExternalFilesDir(null), "output").apply { mkdirs() }
        val plainFile = File(outDir, "aggregated.txt")
        val base64File = File(outDir, "aggregated_base64.txt")

        BufferedWriter(OutputStreamWriter(plainFile.outputStream(), Charsets.UTF_8)).use { writer ->
            lines.forEachIndexed { index, line ->
                if (index > 0) writer.write("\n")
                writer.write(line)
            }
        }

        Base64OutputStream(FileOutputStream(base64File), Base64.NO_WRAP).use { b64 ->
            lines.forEachIndexed { index, line ->
                if (index > 0) b64.write("\n".toByteArray(Charsets.UTF_8))
                b64.write(line.toByteArray(Charsets.UTF_8))
            }
        }

        return plainFile to base64File
    }

    private fun buildPreviewText(lines: List<String>): String {
        if (lines.isEmpty()) {
            return "Ни одной строки vless:// или vmess:// не найдено."
        }
        val preview = lines.take(previewLimit).joinToString("\n")
        return if (lines.size > previewLimit) {
            "$preview\n\n… показаны первые $previewLimit из ${lines.size} строк.\n" +
                "Полный список — в сохранённых файлах (кнопка «Сохранить/поделиться»)."
        } else {
            preview
        }
    }

    private fun buildStatusText(
        result: Aggregator.AggregationResult,
        finalCount: Int,
        truncated: Boolean
    ): String {
        val sb = StringBuilder()
        sb.append("Источников опрошено: ${Sources.URLS.size}\n")
        sb.append("Из них с ошибкой: ${result.errors.size}\n")
        sb.append("Собрано строк всего (с дублями): ${result.totalCollected}\n")
        sb.append("После удаления дублей: ${result.lines.size}\n")
        if (truncated) {
            sb.append("В файл сохранено (ограничение $maxOutputLines): $finalCount\n")
        }

        if (result.errors.isNotEmpty()) {
            sb.append("\nОшибки загрузки:\n")
            result.errors.forEach { (url, message) ->
                sb.append("• $url — $message\n")
            }
        }
        return sb.toString()
    }

    private fun copyBase64ToClipboard() {
        val file = lastBase64File ?: return
        if (!file.exists()) return

        if (file.length() > clipboardSafeSizeBytes) {
            Toast.makeText(
                this,
                "Список слишком большой для буфера обмена (${file.length() / 1024} КБ). " +
                    "Используйте «Сохранить/поделиться».",
                Toast.LENGTH_LONG
            ).show()
            return
        }

        lifecycleScope.launch {
            val content = withContext(Dispatchers.IO) { file.readText(Charsets.UTF_8) }
            val clipboard = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
            clipboard.setPrimaryClip(ClipData.newPlainText("vpn-subscription-base64", content))
            Toast.makeText(this@MainActivity, "Base64-подписка скопирована в буфер обмена", Toast.LENGTH_SHORT).show()
        }
    }

    private fun shareFiles() {
        val plain = lastPlainFile
        val base64 = lastBase64File
        if (plain == null || base64 == null || !plain.exists() || !base64.exists()) return

        try {
            val authority = "$packageName.fileprovider"
            val uris = arrayListOf(
                FileProvider.getUriForFile(this, authority, plain),
                FileProvider.getUriForFile(this, authority, base64)
            )

            val shareIntent = Intent(Intent.ACTION_SEND_MULTIPLE).apply {
                type = "text/plain"
                putParcelableArrayListExtra(Intent.EXTRA_STREAM, uris)
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }
            startActivity(Intent.createChooser(shareIntent, "Поделиться файлами подписки"))

            Toast.makeText(
                this,
                "Файлы сохранены в: ${plain.parentFile?.absolutePath}",
                Toast.LENGTH_LONG
            ).show()
        } catch (e: Exception) {
            Toast.makeText(this, "Ошибка: ${e.message}", Toast.LENGTH_LONG).show()
        }
    }
}